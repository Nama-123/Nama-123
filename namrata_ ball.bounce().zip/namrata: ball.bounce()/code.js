var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["38f8f3ea-626d-4e4c-9c15-a2b7fae3bdba","fb832197-2f1a-4d62-8136-ae1491242b0a","926021ed-94bd-40c0-bfe9-b34d79d90e89"],"propsByKey":{"38f8f3ea-626d-4e4c-9c15-a2b7fae3bdba":{"name":"ball1","sourceUrl":"assets/api/v1/animation-library/gamelab/xO0n9nwJzb7DzH6thbotnjeQ6keriHM2/category_sports/croquetball.png","frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":60,"version":"xO0n9nwJzb7DzH6thbotnjeQ6keriHM2","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xO0n9nwJzb7DzH6thbotnjeQ6keriHM2/category_sports/croquetball.png"},"fb832197-2f1a-4d62-8136-ae1491242b0a":{"name":"ball2","sourceUrl":null,"frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":60,"version":"tz55Kpixhp_npi2GhmJNvtk7hojy06zI","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/fb832197-2f1a-4d62-8136-ae1491242b0a.png"},"926021ed-94bd-40c0-bfe9-b34d79d90e89":{"name":"abstract_15_1","sourceUrl":"assets/api/v1/animation-library/gamelab/kpGIKirow4l3xRdN_BYD7pW3aVlfysex/category_backgrounds/abstract_15.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"kpGIKirow4l3xRdN_BYD7pW3aVlfysex","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/kpGIKirow4l3xRdN_BYD7pW3aVlfysex/category_backgrounds/abstract_15.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var backgroundSprite = createSprite(400, 400);
backgroundSprite.setAnimation("abstract_15_1");
backgroundSprite.scale = 5

var ball1 = createSprite(200, 200);
ball1.setAnimation("ball1");
ball1.scale = 0.2;



var ball2 = createSprite(200, 300);
ball2.setAnimation("ball2");
ball2.scale = 0.2;



createEdgeSprites();






function draw() {
  

  
  
  drawSprites();
  
    
  textSize(20);
  text("bounce property",150,40);
  text("press space key to start",150,370);
  
  
  if(mouseDown("leftButton")){
    ball1.velocityY = 6;
  }
  
  ball1.bounceOff(edges);
  ball2.bounceOff(edges);
  
  ball1.bounce(ball2);
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
